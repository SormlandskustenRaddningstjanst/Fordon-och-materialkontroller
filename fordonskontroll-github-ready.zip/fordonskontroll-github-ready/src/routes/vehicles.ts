import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db/pool.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const vehicleRouter = Router();

vehicleRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const stationId = req.query.stationId as string | undefined;
    const result = await pool.query(
      `select v.id, v.name, v.call_sign, v.registration_number, v.status,
              s.name as station_name, vt.name as vehicle_type
       from vehicles v
       join stations s on s.id = v.station_id
       join vehicle_types vt on vt.id = v.vehicle_type_id
       where v.is_active = true
         and ($1::uuid is null or v.station_id = $1::uuid)
       order by s.name, v.name`,
      [stationId ?? null]
    );

    res.json(result.rows);
  })
);

vehicleRouter.get(
  '/due',
  asyncHandler(async (_req, res) => {
    const result = await pool.query(
      `select * from v_vehicle_due_controls
       where is_due = true
       order by station_name, vehicle_name, interval`
    );
    res.json(result.rows);
  })
);

vehicleRouter.get(
  '/:vehicleId/templates/:interval',
  asyncHandler(async (req, res) => {
    const params = z.object({
      vehicleId: z.string().uuid(),
      interval: z.enum(['DAY', 'WEEK', 'MONTH', 'QUARTER'])
    }).parse(req.params);

    const result = await pool.query(
      `select t.id as template_id,
              t.name as template_name,
              t.interval,
              ci.id as checklist_item_id,
              ci.section_name,
              ci.sort_order,
              ci.title,
              ci.short_description,
              ci.instruction_text,
              ci.failure_criteria,
              ci.control_method,
              ci.response_type,
              ci.is_required,
              ci.is_critical,
              ci.require_comment_on_failure,
              ci.require_photo_on_failure,
              coalesce(
                json_agg(
                  json_build_object(
                    'id', cim.id,
                    'mediaType', cim.media_type,
                    'title', cim.title,
                    'description', cim.description,
                    'url', cim.url,
                    'sortOrder', cim.sort_order
                  )
                ) filter (where cim.id is not null), '[]'::json
              ) as media
       from vehicle_template_assignments vta
       join checklist_templates t on t.id = vta.template_id
       join checklist_items ci on ci.template_id = t.id
       left join checklist_item_media cim on cim.checklist_item_id = ci.id
       where vta.vehicle_id = $1
         and t.interval = $2::control_interval
       group by t.id, t.name, t.interval,
                ci.id, ci.section_name, ci.sort_order, ci.title,
                ci.short_description, ci.instruction_text, ci.failure_criteria,
                ci.control_method, ci.response_type, ci.is_required,
                ci.is_critical, ci.require_comment_on_failure,
                ci.require_photo_on_failure
       order by ci.sort_order`,
      [params.vehicleId, params.interval]
    );

    res.json(result.rows);
  })
);
