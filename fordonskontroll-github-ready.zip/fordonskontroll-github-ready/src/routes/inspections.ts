import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db/pool.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const inspectionRouter = Router();

const startInspectionSchema = z.object({
  objectType: z.enum(['VEHICLE', 'MATERIAL']),
  vehicleId: z.string().uuid().optional(),
  materialId: z.string().uuid().optional(),
  templateId: z.string().uuid(),
  interval: z.enum(['DAY', 'WEEK', 'MONTH', 'QUARTER']),
  performedBy: z.string().uuid(),
  stationId: z.string().uuid().optional(),
  notes: z.string().optional()
});

inspectionRouter.post(
  '/start',
  asyncHandler(async (req, res) => {
    const body = startInspectionSchema.parse(req.body);

    const result = await pool.query(
      `insert into inspections (
          object_type, vehicle_id, material_id, template_id, interval,
          performed_by, station_id, notes
       ) values ($1, $2, $3, $4, $5::control_interval, $6, $7, $8)
       returning *`,
      [
        body.objectType,
        body.vehicleId ?? null,
        body.materialId ?? null,
        body.templateId,
        body.interval,
        body.performedBy,
        body.stationId ?? null,
        body.notes ?? null
      ]
    );

    res.status(201).json(result.rows[0]);
  })
);

const resultSchema = z.object({
  checklistItemId: z.string().uuid(),
  passed: z.boolean().nullable().optional(),
  responseText: z.string().optional(),
  responseNumber: z.number().optional(),
  responseDate: z.string().optional(),
  responseOption: z.string().optional(),
  commentText: z.string().optional()
});

inspectionRouter.post(
  '/:inspectionId/results',
  asyncHandler(async (req, res) => {
    const { inspectionId } = z.object({ inspectionId: z.string().uuid() }).parse(req.params);
    const body = resultSchema.parse(req.body);

    const result = await pool.query(
      `insert into inspection_results (
          inspection_id, checklist_item_id, passed, response_text,
          response_number, response_date, response_option, comment_text
       ) values ($1, $2, $3, $4, $5, $6, $7, $8)
       on conflict (inspection_id, checklist_item_id)
       do update set
         passed = excluded.passed,
         response_text = excluded.response_text,
         response_number = excluded.response_number,
         response_date = excluded.response_date,
         response_option = excluded.response_option,
         comment_text = excluded.comment_text
       returning *`,
      [
        inspectionId,
        body.checklistItemId,
        body.passed ?? null,
        body.responseText ?? null,
        body.responseNumber ?? null,
        body.responseDate ?? null,
        body.responseOption ?? null,
        body.commentText ?? null
      ]
    );

    res.status(201).json(result.rows[0]);
  })
);

inspectionRouter.post(
  '/:inspectionId/complete',
  asyncHandler(async (req, res) => {
    const { inspectionId } = z.object({ inspectionId: z.string().uuid() }).parse(req.params);
    await pool.query(`select complete_inspection($1)`, [inspectionId]);
    const result = await pool.query(`select * from inspections where id = $1`, [inspectionId]);
    res.json(result.rows[0]);
  })
);
