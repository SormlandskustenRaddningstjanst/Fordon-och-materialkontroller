import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db/pool.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const deviationRouter = Router();

const createFromResultSchema = z.object({
  inspectionResultId: z.string().uuid(),
  priority: z.enum(['LOW', 'NORMAL', 'HIGH', 'CRITICAL']).optional(),
  responsibleUserId: z.string().uuid().optional()
});

deviationRouter.post(
  '/from-result',
  asyncHandler(async (req, res) => {
    const body = createFromResultSchema.parse(req.body);
    const result = await pool.query(
      `select create_deviation_from_failed_result($1, $2::deviation_priority, $3) as id`,
      [body.inspectionResultId, body.priority ?? 'NORMAL', body.responsibleUserId ?? null]
    );
    res.status(201).json(result.rows[0]);
  })
);

deviationRouter.get(
  '/open',
  asyncHandler(async (_req, res) => {
    const result = await pool.query(
      `select d.id, d.title, d.priority, d.status, d.reported_at,
              v.name as vehicle_name, m.name as material_name,
              u.full_name as responsible_user
       from deviations d
       left join vehicles v on v.id = d.vehicle_id
       left join materials m on m.id = d.material_id
       left join users u on u.id = d.responsible_user_id
       where d.status not in ('RESOLVED', 'CLOSED')
       order by d.priority desc, d.reported_at desc`
    );
    res.json(result.rows);
  })
);
