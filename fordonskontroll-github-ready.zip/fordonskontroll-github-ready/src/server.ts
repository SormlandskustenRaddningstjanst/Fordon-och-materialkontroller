import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { env } from './config/env.js';
import { healthRouter } from './routes/health.js';
import { vehicleRouter } from './routes/vehicles.js';
import { inspectionRouter } from './routes/inspections.js';
import { deviationRouter } from './routes/deviations.js';

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());

app.use('/health', healthRouter);
app.use('/api/vehicles', vehicleRouter);
app.use('/api/inspections', inspectionRouter);
app.use('/api/deviations', deviationRouter);

app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({
    error: 'Internal server error',
    details: err instanceof Error ? err.message : 'Unknown error'
  });
});

app.listen(env.PORT, () => {
  console.log(`Fordonskontroll API listening on port ${env.PORT}`);
});
