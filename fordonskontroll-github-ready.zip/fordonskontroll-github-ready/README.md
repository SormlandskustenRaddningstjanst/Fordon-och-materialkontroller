# Fordonskontroll API

GitHub-redo starterprojekt för fordons- och materialkontroller inom räddningstjänsten.

## Ingår
- TypeScript + Express API
- PostgreSQL-koppling
- SQL-schema för checklistor, material, fordon, avvikelser och media
- Endpoints för fordon, kontroller och avvikelser
- Stöd för daglig, vecko-, månads- och kvartalskontroll
- Instruktionstext och instruktionsfilmer per kontrollpunkt

## Start
```bash
npm install
cp .env.example .env
npm run dev
```

## Databas
Kör SQL-filen i `sql/fordonskontroll_full.sql` mot PostgreSQL.

## Exempelendpoints
- `GET /health`
- `GET /api/vehicles`
- `GET /api/vehicles/due`
- `GET /api/vehicles/:vehicleId/templates/:interval`
- `POST /api/inspections/start`
- `POST /api/inspections/:inspectionId/results`
- `POST /api/inspections/:inspectionId/complete`
- `POST /api/deviations/from-result`
- `GET /api/deviations/open`

## Rekommenderad nästa nivå
- Auth med Supabase Auth eller Clerk
- Filuppladdning till Supabase Storage / S3
- Rollstyrning per station
- Frontend i Next.js eller React Native
