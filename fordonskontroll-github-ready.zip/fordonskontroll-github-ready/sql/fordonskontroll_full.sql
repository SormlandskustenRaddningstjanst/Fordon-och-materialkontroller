-- =========================================================
-- FORDONS- OCH MATERIALKONTROLLER
-- PostgreSQL
-- =========================================================

begin;

create extension if not exists pgcrypto;

do $$
begin
  if not exists (select 1 from pg_type where typname = 'control_interval') then
    create type control_interval as enum ('DAY', 'WEEK', 'MONTH', 'QUARTER');
  end if;
  if not exists (select 1 from pg_type where typname = 'object_type') then
    create type object_type as enum ('VEHICLE', 'MATERIAL');
  end if;
  if not exists (select 1 from pg_type where typname = 'response_type') then
    create type response_type as enum ('OK_NOT_OK','YES_NO','NUMBER','TEXT','DATE','SELECT');
  end if;
  if not exists (select 1 from pg_type where typname = 'vehicle_status') then
    create type vehicle_status as enum ('IN_SERVICE','IN_SERVICE_WITH_DEVIATION','NOT_READY','OUT_OF_SERVICE','UNDER_REPAIR');
  end if;
  if not exists (select 1 from pg_type where typname = 'inspection_status') then
    create type inspection_status as enum ('STARTED','COMPLETED','SIGNED','CANCELLED');
  end if;
  if not exists (select 1 from pg_type where typname = 'deviation_priority') then
    create type deviation_priority as enum ('LOW','NORMAL','HIGH','CRITICAL');
  end if;
  if not exists (select 1 from pg_type where typname = 'deviation_status') then
    create type deviation_status as enum ('NEW','STARTED','WAITING','RESOLVED','CLOSED');
  end if;
  if not exists (select 1 from pg_type where typname = 'media_type') then
    create type media_type as enum ('VIDEO','IMAGE','DOCUMENT','LINK');
  end if;
end $$;

create table if not exists stations (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists roles (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text
);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  station_id uuid references stations(id),
  role_id uuid references roles(id),
  full_name text not null,
  email text unique,
  phone text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists vehicle_types (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text
);

create table if not exists material_types (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text
);

create table if not exists vehicles (
  id uuid primary key default gen_random_uuid(),
  station_id uuid not null references stations(id),
  vehicle_type_id uuid not null references vehicle_types(id),
  call_sign text,
  registration_number text,
  internal_number text,
  name text not null,
  status vehicle_status not null default 'IN_SERVICE',
  responsible_user_id uuid references users(id),
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists materials (
  id uuid primary key default gen_random_uuid(),
  station_id uuid references stations(id),
  vehicle_id uuid references vehicles(id) on delete set null,
  material_type_id uuid not null references material_types(id),
  name text not null,
  serial_number text,
  location_text text,
  quantity numeric(10,2),
  best_before_date date,
  calibration_due_date date,
  service_due_date date,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (vehicle_id is not null or station_id is not null)
);

create table if not exists checklist_templates (
  id uuid primary key default gen_random_uuid(),
  object_type object_type not null,
  vehicle_type_id uuid references vehicle_types(id),
  material_type_id uuid references material_types(id),
  interval control_interval not null,
  code text not null unique,
  name text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    (object_type = 'VEHICLE' and vehicle_type_id is not null and material_type_id is null)
    or
    (object_type = 'MATERIAL' and material_type_id is not null and vehicle_type_id is null)
  )
);

create table if not exists checklist_items (
  id uuid primary key default gen_random_uuid(),
  template_id uuid not null references checklist_templates(id) on delete cascade,
  section_name text not null,
  sort_order integer not null,
  title text not null,
  short_description text,
  instruction_text text,
  failure_criteria text,
  control_method text,
  response_type response_type not null default 'OK_NOT_OK',
  expected_value_text text,
  unit text,
  is_required boolean not null default true,
  is_critical boolean not null default false,
  require_comment_on_failure boolean not null default true,
  require_photo_on_failure boolean not null default false,
  require_video_on_failure boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists checklist_item_options (
  id uuid primary key default gen_random_uuid(),
  checklist_item_id uuid not null references checklist_items(id) on delete cascade,
  sort_order integer not null,
  option_value text not null,
  option_label text not null
);

create table if not exists checklist_item_media (
  id uuid primary key default gen_random_uuid(),
  checklist_item_id uuid not null references checklist_items(id) on delete cascade,
  media_type media_type not null,
  title text not null,
  description text,
  url text not null,
  sort_order integer not null default 1,
  created_at timestamptz not null default now()
);

create table if not exists vehicle_template_assignments (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid not null references vehicles(id) on delete cascade,
  template_id uuid not null references checklist_templates(id) on delete cascade,
  unique (vehicle_id, template_id)
);

create table if not exists material_template_assignments (
  id uuid primary key default gen_random_uuid(),
  material_id uuid not null references materials(id) on delete cascade,
  template_id uuid not null references checklist_templates(id) on delete cascade,
  unique (material_id, template_id)
);

create table if not exists inspections (
  id uuid primary key default gen_random_uuid(),
  object_type object_type not null,
  vehicle_id uuid references vehicles(id),
  material_id uuid references materials(id),
  template_id uuid not null references checklist_templates(id),
  interval control_interval not null,
  performed_by uuid not null references users(id),
  station_id uuid references stations(id),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  signed_at timestamptz,
  status inspection_status not null default 'STARTED',
  summary_status vehicle_status,
  notes text,
  check (
    (object_type = 'VEHICLE' and vehicle_id is not null and material_id is null)
    or
    (object_type = 'MATERIAL' and material_id is not null and vehicle_id is null)
  )
);

create table if not exists inspection_results (
  id uuid primary key default gen_random_uuid(),
  inspection_id uuid not null references inspections(id) on delete cascade,
  checklist_item_id uuid not null references checklist_items(id),
  passed boolean,
  response_text text,
  response_number numeric(12,2),
  response_date date,
  response_option text,
  comment_text text,
  created_at timestamptz not null default now(),
  unique (inspection_id, checklist_item_id)
);

create table if not exists inspection_result_media (
  id uuid primary key default gen_random_uuid(),
  inspection_result_id uuid not null references inspection_results(id) on delete cascade,
  media_type media_type not null,
  title text,
  url text not null,
  created_at timestamptz not null default now()
);

create table if not exists deviations (
  id uuid primary key default gen_random_uuid(),
  object_type object_type not null,
  vehicle_id uuid references vehicles(id),
  material_id uuid references materials(id),
  inspection_id uuid references inspections(id),
  inspection_result_id uuid references inspection_results(id),
  checklist_item_id uuid references checklist_items(id),
  title text not null,
  description text,
  priority deviation_priority not null default 'NORMAL',
  status deviation_status not null default 'NEW',
  affects_readiness boolean not null default false,
  responsible_user_id uuid references users(id),
  reported_by uuid references users(id),
  reported_at timestamptz not null default now(),
  resolved_at timestamptz,
  closed_at timestamptz,
  check (
    (object_type = 'VEHICLE' and vehicle_id is not null and material_id is null)
    or
    (object_type = 'MATERIAL' and material_id is not null and vehicle_id is null)
  )
);

create table if not exists deviation_actions (
  id uuid primary key default gen_random_uuid(),
  deviation_id uuid not null references deviations(id) on delete cascade,
  action_text text not null,
  action_status deviation_status,
  created_by uuid references users(id),
  created_at timestamptz not null default now()
);

create table if not exists deviation_media (
  id uuid primary key default gen_random_uuid(),
  deviation_id uuid not null references deviations(id) on delete cascade,
  media_type media_type not null,
  title text,
  url text not null,
  created_at timestamptz not null default now()
);

create table if not exists control_schedule_rules (
  id uuid primary key default gen_random_uuid(),
  interval control_interval not null unique,
  due_after_days integer not null,
  warning_after_days integer,
  description text
);

insert into control_schedule_rules (interval, due_after_days, warning_after_days, description)
values
  ('DAY', 1, 1, 'Daglig kontroll'),
  ('WEEK', 7, 6, 'Veckokontroll'),
  ('MONTH', 30, 25, 'Månadskontroll'),
  ('QUARTER', 90, 80, 'Kvartalskontroll')
on conflict (interval) do update
set due_after_days = excluded.due_after_days,
    warning_after_days = excluded.warning_after_days,
    description = excluded.description;

create index if not exists idx_vehicles_station on vehicles(station_id);
create index if not exists idx_vehicles_type on vehicles(vehicle_type_id);
create index if not exists idx_materials_vehicle on materials(vehicle_id);
create index if not exists idx_templates_interval on checklist_templates(interval);
create index if not exists idx_items_template on checklist_items(template_id, sort_order);
create index if not exists idx_inspections_vehicle on inspections(vehicle_id, started_at desc);
create index if not exists idx_inspections_material on inspections(material_id, started_at desc);
create index if not exists idx_deviations_vehicle on deviations(vehicle_id, status, priority);
create index if not exists idx_deviations_material on deviations(material_id, status, priority);

create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists trg_stations_updated_at on stations;
create trigger trg_stations_updated_at before update on stations for each row execute function set_updated_at();
drop trigger if exists trg_vehicles_updated_at on vehicles;
create trigger trg_vehicles_updated_at before update on vehicles for each row execute function set_updated_at();
drop trigger if exists trg_materials_updated_at on materials;
create trigger trg_materials_updated_at before update on materials for each row execute function set_updated_at();
drop trigger if exists trg_templates_updated_at on checklist_templates;
create trigger trg_templates_updated_at before update on checklist_templates for each row execute function set_updated_at();

create or replace function complete_inspection(p_inspection_id uuid)
returns void
language plpgsql
as $$
declare
  v_vehicle_id uuid;
  v_object_type object_type;
  v_has_critical_failure boolean := false;
  v_has_any_failure boolean := false;
begin
  select vehicle_id, object_type into v_vehicle_id, v_object_type from inspections where id = p_inspection_id;
  if not found then
    raise exception 'Inspection not found: %', p_inspection_id;
  end if;
  select exists (
    select 1
    from inspection_results ir
    join checklist_items ci on ci.id = ir.checklist_item_id
    where ir.inspection_id = p_inspection_id
      and coalesce(ir.passed, false) = false
      and ci.is_critical = true
  ) into v_has_critical_failure;
  select exists (
    select 1 from inspection_results ir
    where ir.inspection_id = p_inspection_id
      and coalesce(ir.passed, false) = false
  ) into v_has_any_failure;
  update inspections
     set completed_at = now(), signed_at = now(), status = 'SIGNED',
         summary_status = case
           when v_object_type = 'MATERIAL' then null
           when v_has_critical_failure then 'NOT_READY'
           when v_has_any_failure then 'IN_SERVICE_WITH_DEVIATION'
           else 'IN_SERVICE'
         end
   where id = p_inspection_id;
  if v_object_type = 'VEHICLE' then
    update vehicles
       set status = case
         when v_has_critical_failure then 'NOT_READY'
         when v_has_any_failure then 'IN_SERVICE_WITH_DEVIATION'
         else 'IN_SERVICE'
       end
     where id = v_vehicle_id;
  end if;
end $$;

create or replace function create_deviation_from_failed_result(
  p_inspection_result_id uuid,
  p_priority deviation_priority default 'NORMAL',
  p_responsible_user_id uuid default null
)
returns uuid
language plpgsql
as $$
declare
  v_result record;
  v_deviation_id uuid;
begin
  select ir.id as inspection_result_id,
         i.id as inspection_id,
         i.object_type,
         i.vehicle_id,
         i.material_id,
         i.performed_by,
         ci.id as checklist_item_id,
         ci.title,
         ci.is_critical,
         coalesce(ir.comment_text, ci.failure_criteria) as description_text
    into v_result
  from inspection_results ir
  join inspections i on i.id = ir.inspection_id
  join checklist_items ci on ci.id = ir.checklist_item_id
  where ir.id = p_inspection_result_id;
  if not found then
    raise exception 'Inspection result not found: %', p_inspection_result_id;
  end if;
  insert into deviations (
    object_type, vehicle_id, material_id, inspection_id, inspection_result_id,
    checklist_item_id, title, description, priority, status, affects_readiness,
    responsible_user_id, reported_by
  ) values (
    v_result.object_type, v_result.vehicle_id, v_result.material_id,
    v_result.inspection_id, v_result.inspection_result_id, v_result.checklist_item_id,
    v_result.title, v_result.description_text,
    case when v_result.is_critical then 'CRITICAL' else p_priority end,
    'NEW', v_result.is_critical, p_responsible_user_id, v_result.performed_by
  ) returning id into v_deviation_id;
  return v_deviation_id;
end $$;

create or replace view v_vehicle_due_controls as
with last_done as (
  select i.vehicle_id, i.interval, max(i.completed_at) as last_completed_at
  from inspections i
  where i.object_type = 'VEHICLE' and i.status in ('COMPLETED', 'SIGNED')
  group by i.vehicle_id, i.interval
)
select v.id as vehicle_id, v.name as vehicle_name, v.call_sign, s.name as station_name,
       t.interval, r.due_after_days, ld.last_completed_at,
       (ld.last_completed_at + make_interval(days => r.due_after_days)) as due_at,
       case
         when ld.last_completed_at is null then true
         when (ld.last_completed_at + make_interval(days => r.due_after_days)) <= now() then true
         else false
       end as is_due
from vehicles v
join stations s on s.id = v.station_id
join vehicle_template_assignments vta on vta.vehicle_id = v.id
join checklist_templates t on t.id = vta.template_id and t.object_type = 'VEHICLE'
join control_schedule_rules r on r.interval = t.interval
left join last_done ld on ld.vehicle_id = v.id and ld.interval = t.interval
where v.is_active = true;

create or replace view v_material_due_controls as
with last_done as (
  select i.material_id, i.interval, max(i.completed_at) as last_completed_at
  from inspections i
  where i.object_type = 'MATERIAL' and i.status in ('COMPLETED', 'SIGNED')
  group by i.material_id, i.interval
)
select m.id as material_id, m.name as material_name, t.interval, r.due_after_days,
       ld.last_completed_at,
       (ld.last_completed_at + make_interval(days => r.due_after_days)) as due_at,
       case
         when ld.last_completed_at is null then true
         when (ld.last_completed_at + make_interval(days => r.due_after_days)) <= now() then true
         else false
       end as is_due
from materials m
join material_template_assignments mta on mta.material_id = m.id
join checklist_templates t on t.id = mta.template_id and t.object_type = 'MATERIAL'
join control_schedule_rules r on r.interval = t.interval
left join last_done ld on ld.material_id = m.id and ld.interval = t.interval
where m.is_active = true;

insert into roles (code, name, description)
values
  ('FIREFIGHTER', 'Brandman', 'Utför kontroller och rapporterar avvikelser'),
  ('TEAM_LEADER', 'Styrkeledare', 'Ser status och följer upp'),
  ('VEHICLE_MANAGER', 'Fordonsansvarig', 'Ansvarar för åtgärder'),
  ('ADMIN', 'Administratör', 'Hantera mallar, objekt och användare')
on conflict (code) do update set name = excluded.name, description = excluded.description;

insert into vehicle_types (code, name, description)
values
  ('FIRE_ENGINE', 'Släckbil', 'Släck-/räddningsfordon'),
  ('COMMAND_CAR', 'IL-bil', 'Insatsledningsfordon / småbil'),
  ('BOAT', 'Båt', 'Räddningsbåt'),
  ('ATV', 'Fyrhjuling / terrängfordon', 'Terränggående enhet'),
  ('SPECIAL', 'Specialfordon', 'Övrigt specialfordon')
on conflict (code) do update set name = excluded.name, description = excluded.description;

insert into material_types (code, name, description)
values
  ('BA_APPARATUS', 'Andningsapparat', 'Rökskydd / andningsapparat'),
  ('DEFIBRILLATOR', 'Defibrillator', 'Hjärtstartare'),
  ('CHAINSAW', 'Motorsåg', 'Motorsåg och tillbehör')
on conflict (code) do update set name = excluded.name, description = excluded.description;

with vt as (select code, id from vehicle_types), mt as (select code, id from material_types)
insert into checklist_templates (object_type, vehicle_type_id, material_type_id, interval, code, name, description)
values
  ('VEHICLE', (select id from vt where code='FIRE_ENGINE'), null, 'DAY', 'FIRE_ENGINE_DAY', 'Släckbil – Daglig kontroll', 'Daglig kontroll för släckbil'),
  ('VEHICLE', (select id from vt where code='FIRE_ENGINE'), null, 'WEEK', 'FIRE_ENGINE_WEEK', 'Släckbil – Veckokontroll', 'Veckokontroll för släckbil'),
  ('VEHICLE', (select id from vt where code='FIRE_ENGINE'), null, 'MONTH', 'FIRE_ENGINE_MONTH', 'Släckbil – Månadskontroll', 'Månadskontroll för släckbil'),
  ('VEHICLE', (select id from vt where code='FIRE_ENGINE'), null, 'QUARTER', 'FIRE_ENGINE_QUARTER', 'Släckbil – Kvartalskontroll', 'Kvartalskontroll för släckbil'),
  ('VEHICLE', (select id from vt where code='COMMAND_CAR'), null, 'DAY', 'COMMAND_CAR_DAY', 'IL-bil – Daglig kontroll', 'Daglig kontroll för IL-bil'),
  ('VEHICLE', (select id from vt where code='COMMAND_CAR'), null, 'WEEK', 'COMMAND_CAR_WEEK', 'IL-bil – Veckokontroll', 'Veckokontroll för IL-bil'),
  ('VEHICLE', (select id from vt where code='COMMAND_CAR'), null, 'MONTH', 'COMMAND_CAR_MONTH', 'IL-bil – Månadskontroll', 'Månadskontroll för IL-bil'),
  ('VEHICLE', (select id from vt where code='COMMAND_CAR'), null, 'QUARTER', 'COMMAND_CAR_QUARTER', 'IL-bil – Kvartalskontroll', 'Kvartalskontroll för IL-bil'),
  ('VEHICLE', (select id from vt where code='BOAT'), null, 'DAY', 'BOAT_DAY', 'Båt – Daglig kontroll', 'Daglig kontroll för båt'),
  ('VEHICLE', (select id from vt where code='BOAT'), null, 'WEEK', 'BOAT_WEEK', 'Båt – Veckokontroll', 'Veckokontroll för båt'),
  ('VEHICLE', (select id from vt where code='BOAT'), null, 'MONTH', 'BOAT_MONTH', 'Båt – Månadskontroll', 'Månadskontroll för båt'),
  ('VEHICLE', (select id from vt where code='BOAT'), null, 'QUARTER', 'BOAT_QUARTER', 'Båt – Kvartalskontroll', 'Kvartalskontroll för båt'),
  ('MATERIAL', null, (select id from mt where code='BA_APPARATUS'), 'DAY', 'BA_APPARATUS_DAY', 'Andningsapparat – Daglig kontroll', 'Daglig kontroll andningsapparat'),
  ('MATERIAL', null, (select id from mt where code='BA_APPARATUS'), 'WEEK', 'BA_APPARATUS_WEEK', 'Andningsapparat – Veckokontroll', 'Veckokontroll andningsapparat'),
  ('MATERIAL', null, (select id from mt where code='BA_APPARATUS'), 'MONTH', 'BA_APPARATUS_MONTH', 'Andningsapparat – Månadskontroll', 'Månadskontroll andningsapparat'),
  ('MATERIAL', null, (select id from mt where code='BA_APPARATUS'), 'QUARTER', 'BA_APPARATUS_QUARTER', 'Andningsapparat – Kvartalskontroll', 'Kvartalskontroll andningsapparat'),
  ('MATERIAL', null, (select id from mt where code='DEFIBRILLATOR'), 'DAY', 'DEFIBRILLATOR_DAY', 'Defibrillator – Daglig kontroll', 'Daglig kontroll defibrillator'),
  ('MATERIAL', null, (select id from mt where code='DEFIBRILLATOR'), 'WEEK', 'DEFIBRILLATOR_WEEK', 'Defibrillator – Veckokontroll', 'Veckokontroll defibrillator'),
  ('MATERIAL', null, (select id from mt where code='DEFIBRILLATOR'), 'MONTH', 'DEFIBRILLATOR_MONTH', 'Defibrillator – Månadskontroll', 'Månadskontroll defibrillator'),
  ('MATERIAL', null, (select id from mt where code='DEFIBRILLATOR'), 'QUARTER', 'DEFIBRILLATOR_QUARTER', 'Defibrillator – Kvartalskontroll', 'Kvartalskontroll defibrillator'),
  ('MATERIAL', null, (select id from mt where code='CHAINSAW'), 'DAY', 'CHAINSAW_DAY', 'Motorsåg – Daglig kontroll', 'Daglig kontroll motorsåg'),
  ('MATERIAL', null, (select id from mt where code='CHAINSAW'), 'WEEK', 'CHAINSAW_WEEK', 'Motorsåg – Veckokontroll', 'Veckokontroll motorsåg'),
  ('MATERIAL', null, (select id from mt where code='CHAINSAW'), 'MONTH', 'CHAINSAW_MONTH', 'Motorsåg – Månadskontroll', 'Månadskontroll motorsåg'),
  ('MATERIAL', null, (select id from mt where code='CHAINSAW'), 'QUARTER', 'CHAINSAW_QUARTER', 'Motorsåg – Kvartalskontroll', 'Kvartalskontroll motorsåg')
on conflict (code) do update set name = excluded.name, description = excluded.description, interval = excluded.interval;

-- Seed checklist items omitted here for brevity in this repo starter? No, included below.
with tpl as (select code, id from checklist_templates)
insert into checklist_items (template_id, section_name, sort_order, title, short_description, instruction_text, failure_criteria, control_method, response_type, is_required, is_critical, require_comment_on_failure, require_photo_on_failure)
values
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Fordon', 10, 'Fordonsbelysning', 'Kontroll av belysning runt hela fordonet', '1. Starta fordonet. 2. Slå på positionsljus, halvljus och helljus. 3. Aktivera blinkers och bromsljus. 4. Gå runt fordonet och kontrollera samtliga lampor.', 'Någon lampa fungerar inte, blinkar fel eller ger ojämnt ljus.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Fordon', 20, 'Däck (ögonkontroll)', 'Visuell kontroll av samtliga däck', '1. Gå runt fordonet. 2. Kontrollera att inget däck ser platt ut. 3. Leta efter synliga skador, sprickor eller främmande föremål.', 'Synlig skada, underpumpat däck eller främmande föremål.', 'Visuell kontroll', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Fordon', 30, 'Vindrutetorkare', 'Kontroll av torkare och spolning', '1. Starta torkarna. 2. Kontrollera att de går jämnt. 3. Testa spolning. 4. Kontrollera att rutorna blir rena.', 'Torkare går ojämnt, lämnar ränder eller spolning fungerar inte.', 'Funktionstest', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Pump/släcksystem', 40, 'Nivå vatten/skum', 'Kontroll av vatten- och skumnivå', '1. Kontrollera nivåindikator för vatten. 2. Kontrollera nivåindikator för skum. 3. Säkerställ att nivåerna uppfyller lokal kravbild. 4. Kontrollera läckage.', 'För låg nivå eller läckage.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Säkerhet', 50, 'Rökskydd / andningsapparater', 'Kontroll av rökskydd', '1. Kontrollera att rätt antal apparater finns. 2. Kontrollera tryck i flaskor. 3. Kontrollera masker och tillbehör. 4. Säkerställ att utrustningen är redo.', 'Utrustning saknas, har lågt tryck eller är skadad.', 'Visuell kontroll / avläsning', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Utrustning', 60, 'Kompletta fack', 'Kontroll att fack är kompletta', '1. Öppna samtliga fack. 2. Kontrollera att utrustning finns enligt lista. 3. Säkerställ att allt ligger rätt.', 'Saknad utrustning eller oordning som påverkar beredskap.', 'Visuell kontroll mot lista', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Sjukvård', 70, 'Defibrillator', 'Kontroll av hjärtstartare', '1. Kontrollera att defibrillatorn finns på plats. 2. Kontrollera statusindikator. 3. Kontrollera batteri och elektroder.', 'Saknas, felindikering visas eller batteri/elektroder är otjänliga.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_DAY'), 'Ordning', 80, 'Städning hytt/skåp', 'Kontroll av ordning och renlighet', '1. Kontrollera hytt. 2. Kontrollera skåp och lastutrymmen. 3. Återställ utrustning och ta bort skräp.', 'Smutsigt, oordnat eller löst material.', 'Visuell kontroll', 'OK_NOT_OK', true, false, false, false),
((select id from tpl where code='FIRE_ENGINE_WEEK'), 'Funktionstest', 10, 'Pump funktionstest', 'Veckovis test av pump', '1. Starta fordonet. 2. Starta pumpen enligt rutin. 3. Kör vatten. 4. Kontrollera tryck och funktion.', 'Pump startar inte, ger dåligt tryck eller beter sig onormalt.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_WEEK'), 'Funktionstest', 20, 'Blåljus och sirén', 'Test av varningssystem', '1. Aktivera blåljus. 2. Aktivera sirén. 3. Kontrollera alla funktioner runt fordonet.', 'Någon funktion fungerar inte korrekt.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_WEEK'), 'Kommunikation', 30, 'Rakel / radio', 'Test av kommunikationsutrustning', '1. Starta radio/Rakel. 2. Testa kommunikation enligt lokal rutin. 3. Kontrollera ljud och anslutning.', 'Ingen kontakt, dåligt ljud eller enheten startar inte.', 'Funktionstest', 'OK_NOT_OK', true, true, true, false),
((select id from tpl where code='FIRE_ENGINE_WEEK'), 'El', 40, 'Batteri och laddning', 'Kontroll av batterisystem', '1. Kontrollera laddstatus. 2. Kontrollera kablar och laddare. 3. Se efter varningar.', 'Låg laddning, felmeddelande eller skadad anslutning.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='FIRE_ENGINE_WEEK'), 'Utrustning', 50, 'Motorsåg', 'Provkörning och kontroll av motorsåg', '1. Kontrollera bränsle och kedjeolja. 2. Starta sågen. 3. Kontrollera gång och säkerhetsfunktioner.', 'Startar inte, går ojämnt eller har säkerhetsbrister.', 'Funktionstest', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_WEEK'), 'Skyddsutrustning', 60, 'Kemdräkter', 'Kontroll av kemdräkter', '1. Kontrollera att rätt antal finns. 2. Kontrollera skick, dragkedjor och förpackning. 3. Säkerställ korrekt placering.', 'Saknas, är skadade eller felplacerade.', 'Visuell kontroll', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_MONTH'), 'Inventering', 10, 'Full inventering fack', 'Månadsvis inventering', '1. Gå igenom samtliga fack systematiskt. 2. Jämför innehåll mot utrustningslista. 3. Notera avvikelser.', 'Saknade, felplacerade eller skadade artiklar.', 'Inventering mot lista', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_MONTH'), 'Släcksystem', 20, 'Slangar och kopplingar', 'Kontroll av slangar och kopplingar', '1. Kontrollera slangar för slitage, sprickor och skador. 2. Kontrollera kopplingar. 3. Säkerställ att allt är rent och funktionsdugligt.', 'Slitage, läckage, skadade kopplingar eller felkoppling.', 'Visuell kontroll', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_MONTH'), 'El', 30, 'Generator', 'Test av generator under belastning', '1. Starta generatorn. 2. Belasta enligt rutin. 3. Kontrollera stabil drift.', 'Generator startar inte eller klarar inte belastning.', 'Funktionstest', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_MONTH'), 'Säkerhet', 40, 'Brandsläckare', 'Kontroll av brandsläckare', '1. Kontrollera tryckindikator. 2. Kontrollera plombering. 3. Kontrollera att släckare sitter fast.', 'Fel tryck, bruten plomb eller saknad släckare.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='FIRE_ENGINE_QUARTER'), 'Avancerad kontroll', 10, 'Pump – full test', 'Kvartalsvis fulltest av pump', '1. Genomför fullständigt pump-test enligt rutin. 2. Kör pump under belastning. 3. Kontrollera tryck, läckage och stabilitet.', 'Pump klarar inte test, avvikande tryck eller läckage.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_QUARTER'), 'Avancerad kontroll', 20, 'Slangtrycktest', 'Trycktest av slang', '1. Anslut slang enligt rutin. 2. Trycksätt. 3. Kontrollera läckage och hållfasthet.', 'Läckage, skador eller otillräcklig hållfasthet.', 'Trycktest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='FIRE_ENGINE_QUARTER'), 'Säkerhet', 30, 'Säkerhetssystem', 'Kontroll av säkerhetssystem', '1. Kontrollera relevanta säkerhetssystem. 2. Testa funktion enligt rutin. 3. Dokumentera fel.', 'Säkerhetsfunktion fungerar inte korrekt.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='COMMAND_CAR_DAY'), 'Fordon', 10, 'Bränsle', 'Kontroll av bränslenivå', '1. Kontrollera bränslemätare. 2. Säkerställ att nivån uppfyller lokal kravbild.', 'För låg bränslenivå.', 'Visuell kontroll / mätare', 'OK_NOT_OK', true, true, true, false),
((select id from tpl where code='COMMAND_CAR_DAY'), 'Fordon', 20, 'Belysning', 'Kontroll av fordonsbelysning', '1. Slå på belysning. 2. Gå runt bilen. 3. Kontrollera ljus och blinkers.', 'Någon lampa fungerar inte.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='COMMAND_CAR_DAY'), 'Fordon', 30, 'Däck', 'Visuell kontroll av däck', '1. Kontrollera däck visuellt. 2. Leta efter skador och lågt tryck.', 'Synlig skada eller låg nivå.', 'Visuell kontroll', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='COMMAND_CAR_DAY'), 'Kommunikation', 40, 'Radio', 'Kontroll av kommunikationsradio', '1. Starta radio. 2. Säkerställ att enheten fungerar och har kontakt.', 'Ingen kontakt eller fel på enheten.', 'Funktionstest', 'OK_NOT_OK', true, true, true, false),
((select id from tpl where code='COMMAND_CAR_DAY'), 'Sjukvård', 50, 'Sjukvårdsväska', 'Kontroll av sjukvårdsväska', '1. Kontrollera att väskan finns. 2. Kontrollera plombering eller innehåll enligt rutin.', 'Saknas eller är ofullständig.', 'Visuell kontroll', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='COMMAND_CAR_WEEK'), 'Utrustning', 10, 'Full utrustningskontroll', 'Veckovis kontroll av utrustning', '1. Gå igenom utrustningen i fordonet. 2. Kontrollera att allt finns och fungerar.', 'Saknad eller defekt utrustning.', 'Inventering mot lista', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='COMMAND_CAR_WEEK'), 'El', 20, 'Batteri', 'Kontroll av batteri/laddning', '1. Kontrollera laddstatus och felindikeringar. 2. Kontrollera anslutningar.', 'Låg laddning eller felindikering.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='COMMAND_CAR_MONTH'), 'Service', 10, 'Servicekontroll', 'Översyn av servicebehov', '1. Kontrollera serviceindikering och servicebok. 2. Dokumentera eventuellt behov.', 'Service är försenad eller varning finns.', 'Dokument-/systemkontroll', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='COMMAND_CAR_QUARTER'), 'Genomgång', 10, 'Full genomgång', 'Kvartalsvis full genomgång', '1. Gå igenom hela fordonet och utrustningen enligt rutin. 2. Dokumentera alla avvikelser.', 'Avvikelse som påverkar funktion eller beredskap.', 'Full genomgång', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='BOAT_DAY'), 'Båt', 10, 'Bränsle', 'Kontroll av bränslenivå', '1. Kontrollera tanknivå. 2. Säkerställ tillräcklig nivå för insats.', 'För låg nivå eller läckage.', 'Visuell kontroll / mätare', 'OK_NOT_OK', true, true, true, false),
((select id from tpl where code='BOAT_DAY'), 'Båt', 20, 'Motor start', 'Kontroll att motor startar', '1. Starta motor enligt rutin. 2. Lyssna efter avvikande ljud. 3. Kontrollera indikatorer.', 'Motor startar inte eller går onormalt.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BOAT_DAY'), 'Säkerhet', 30, 'Flytvästar', 'Kontroll av flytvästar', '1. Kontrollera antal. 2. Kontrollera skick och placering.', 'Saknas eller är skadade.', 'Visuell kontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BOAT_WEEK'), 'Motor', 10, 'Motor kontroll', 'Veckovis kontroll av motor', '1. Kontrollera motor enligt rutin. 2. Kontrollera olja, kylning och allmän funktion.', 'Felindikering, läckage eller onormal gång.', 'Funktionstest / visuell kontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BOAT_WEEK'), 'El', 20, 'Batteri', 'Kontroll av batteri och laddning', '1. Kontrollera laddstatus. 2. Kontrollera anslutningar.', 'Låg laddning eller fel på anslutning.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='BOAT_MONTH'), 'Navigation', 10, 'Navigationsutrustning', 'Kontroll av navigation och elektronik', '1. Starta navigationsutrustning. 2. Kontrollera att den fungerar och har rätt data.', 'Utrustning startar inte eller visar fel.', 'Funktionstest', 'OK_NOT_OK', true, false, true, false),
((select id from tpl where code='BOAT_QUARTER'), 'Service', 10, 'Full servicegenomgång', 'Kvartalsvis full genomgång av båt', '1. Genomför full genomgång enligt rutin. 2. Dokumentera servicebehov och avvikelser.', 'Fel som påverkar drift eller säkerhet.', 'Full genomgång', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BA_APPARATUS_DAY'), 'Tillgänglighet', 10, 'Finns på plats', 'Kontroll att apparat finns', '1. Kontrollera att apparaten finns på angiven plats. 2. Kontrollera märkning.', 'Apparat saknas eller är felplacerad.', 'Visuell kontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BA_APPARATUS_DAY'), 'Tryck', 20, 'Flasktryck', 'Kontroll av flasktryck', '1. Läs av tryckmätare. 2. Säkerställ att trycket uppfyller lokalt krav.', 'Tryck under godkänd nivå.', 'Avläsning', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BA_APPARATUS_WEEK'), 'Funktion', 10, 'Funktionstest', 'Veckovis funktionstest', '1. Genomför funktionstest enligt tillverkarens och lokal rutin. 2. Dokumentera resultat.', 'Test underkänns eller avviker.', 'Funktionstest', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BA_APPARATUS_MONTH'), 'Genomgång', 10, 'Full kontroll', 'Månadsvis full kontroll', '1. Gå igenom apparat, sele, slangar, mask och tillbehör. 2. Dokumentera avvikelser.', 'Skada, slitage eller funktionsbrist.', 'Full genomgång', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='BA_APPARATUS_QUARTER'), 'Service', 10, 'Service / utökad kontroll', 'Kvartalsvis service', '1. Genomför service enligt lokal rutin eller tillverkarens intervall. 2. Dokumentera åtgärder.', 'Utrustning uppfyller inte krav eller service saknas.', 'Servicekontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='DEFIBRILLATOR_DAY'), 'Tillgänglighet', 10, 'Finns på plats', 'Kontroll av placering', '1. Kontrollera att defibrillatorn finns på plats. 2. Kontrollera att den är åtkomlig.', 'Saknas eller är inte åtkomlig.', 'Visuell kontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='DEFIBRILLATOR_WEEK'), 'Status', 10, 'Batteri och statusindikator', 'Kontroll av batteri/status', '1. Kontrollera batteristatus. 2. Kontrollera statusindikator enligt tillverkarens instruktion.', 'Felindikering eller låg batterinivå.', 'Visuell kontroll / indikator', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='DEFIBRILLATOR_MONTH'), 'Test', 10, 'Självtest / kontroll', 'Månadsvis kontroll av självtest', '1. Kontrollera att enheten genomfört självtest utan fel. 2. Kontrollera elektroder och datum.', 'Fel i självtest eller utgångna elektroder.', 'System-/datumkontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='DEFIBRILLATOR_QUARTER'), 'Service', 10, 'Servicegenomgång', 'Kvartalsvis utökad kontroll/service', '1. Genomför utökad kontroll enligt rutin. 2. Dokumentera åtgärder.', 'Service saknas eller fel kvarstår.', 'Servicekontroll', 'OK_NOT_OK', true, true, true, true),
((select id from tpl where code='CHAINSAW_DAY'), 'Tillgänglighet', 10, 'Finns på plats', 'Kontroll att motorsågen finns', '1. Kontrollera att motorsågen finns på plats. 2. Kontrollera allmän yttre status.', 'Saknas eller uppenbart skadad.', 'Visuell kontroll', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='CHAINSAW_WEEK'), 'Funktion', 10, 'Provkörning', 'Veckovis provkörning av motorsåg', '1. Kontrollera bränsle och kedjeolja. 2. Starta sågen. 3. Kontrollera tomgång, gasrespons och kedjebroms.', 'Startar inte, går dåligt eller har bristande säkerhetsfunktion.', 'Funktionstest', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='CHAINSAW_MONTH'), 'Service', 10, 'Månadsservice', 'Månadsvis genomgång/service', '1. Rengör sågen. 2. Kontrollera kedja, svärd, filter och tändstift enligt rutin.', 'Delar utslitna, skadade eller otjänliga.', 'Servicekontroll', 'OK_NOT_OK', true, false, true, true),
((select id from tpl where code='CHAINSAW_QUARTER'), 'Genomgång', 10, 'Full genomgång', 'Kvartalsvis full genomgång', '1. Genomför full genomgång enligt rutin. 2. Byt slitdelar vid behov. 3. Dokumentera resultat.', 'Fel som påverkar säkerhet eller funktion.', 'Full genomgång', 'OK_NOT_OK', true, false, true, true)
on conflict do nothing;

insert into checklist_item_media (checklist_item_id, media_type, title, description, url, sort_order)
select id, 'VIDEO', 'Instruktionsfilm', 'Byt till verksamhetens riktiga film', 'https://example.org/video/' || id::text, 1
from checklist_items
where title in ('Fordonsbelysning','Pump funktionstest','Rökskydd / andningsapparater','Defibrillator','Provkörning')
on conflict do nothing;

commit;
